import React from 'react';
const Hello = () => {
  return <p>Hola! Hello! привет!</p>
}

export default Hello